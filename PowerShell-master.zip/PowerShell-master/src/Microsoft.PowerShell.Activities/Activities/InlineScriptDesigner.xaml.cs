﻿//
//    Copyright (C) Microsoft.  All rights reserved.
//
﻿#if _NOTARMBUILD_
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Microsoft.PowerShell.Activities
{
    /// <summary>
    /// Interaction logic for InlineScriptDesigner.xaml
    /// </summary>
    public partial class InlineScriptDesigner
    {
        /// <summary>
        /// Create the designer instance
        /// </summary>
        public InlineScriptDesigner()
        {
            InitializeComponent();
        }
    }
}
#endif