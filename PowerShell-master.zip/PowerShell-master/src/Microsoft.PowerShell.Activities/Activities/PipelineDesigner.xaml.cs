﻿//
//    Copyright (C) Microsoft.  All rights reserved.
//
﻿
﻿#if _NOTARMBUILD_
namespace Microsoft.PowerShell.Activities
{
    /// <summary>
    /// Interaction logic for PipelineDesigner.xaml
    /// </summary>
    public partial class PipelineDesigner
    {
        /// <summary>
        /// Default Constructor.
        /// </summary>
        public PipelineDesigner()
        {
            InitializeComponent();
        }

    }
}
#endif