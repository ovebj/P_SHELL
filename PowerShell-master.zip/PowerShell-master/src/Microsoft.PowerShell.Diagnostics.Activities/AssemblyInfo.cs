using System.Reflection;
using System.Security.Permissions;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Diagnostics.CodeAnalysis;


[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersionAttribute("3.0.0.0")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]

[assembly: AssemblyConfiguration("")]
[assembly: ReliabilityContractAttribute(Consistency.MayCorruptAppDomain, Cer.MayFail)]
[assembly: AssemblyTitle("Microsoft.PowerShell.Diagnostics.Activities")]
[assembly: AssemblyDescription("Microsoft.PowerShell.Diagnostics.Activities")]

[module: SuppressMessage("Microsoft.Design", "CA1014:MarkAssembliesWithClsCompliant")]

